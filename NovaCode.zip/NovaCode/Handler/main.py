from tkinter import * 
from time import *
from tkinter import filedialog
import ctypes
import subprocess
from tkinter import filedialog, colorchooser, font
import threading
from tkinter import ttk
from tkinter import messagebox
from tkinter import Label
import time 
import sys 
import os
import requests 

version = "1.1"

window_size_x = "900"
window_size_y = "500"

global tab1_data, tab2_data
tab1_data = ""
tab2_data = ""

bgc = "#242423"
fgc = "cyan"


Server_Data = requests.get("https://raw.githubusercontent.com/Hingdragon/NovaCode/main/Update.json").json()
server_version = Server_Data["version"]
desc = Server_Data["description"]


def main(): 
    window = Tk()

    def console_insert(string:str,clear_console: bool=False):
        code_output.config(state="normal")
        if clear_console == True: 
            code_output.delete(1.0,END)
        code_output.insert(END,string)
        code_output.config(state="disabled")

    def run_code():
        def run_thread():
            data = uinp.get(1.0,END)
            command = 'python rancode.py'
            code_output.delete(1.0,END)
            with open("rancode.py",'w+')as f:
                f.write(data)
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            output, error = process.communicate()
            code_output.config(fg="lime")
            print("Running Code...")
            console_insert(output,True)
            if str(error) != "b''":
                code_output.config(fg="red")
                console_insert(error,True)
        thread = threading.Thread(target=run_thread)
        thread.start()

    def SaveFile():
        file = filedialog.asksaveasfile(defaultextension='.py',
                                        filetypes=[
                                            ("Python File (Recomended)",".py"),
                                            ("Text file",".txt"),
                                            ("All other",".*"),
                                        ])
        filetext = str(uinp.get(1.0,END))
        file.write(filetext)
    def newFile(): 
        window.title("Untitled")
        uinp.delete(1.0,END)
    def openFile(): 
        file = filedialog.askopenfilename(defaultextension='.*',
                                        filetypes=[
                                            ("Python File (Recomended)",".py"),
                                            ("Text file",".txt"),
                                            ("All other",".*"),
                                        ])
        try: 
            window.title(os.path.basename(file))
            uinp.delete(1.0, END)
            c = file
            file = open(file, "r")

            uinp.insert(1.0, file.read())

        except Exception: 
            messagebox.showerror(title="Error With Open",message="Something went wrong when opening this file this may be due to invaild file type or internal error please contact us through our discord @https://discord.gg/7YKCG6FT")
        finally: 
            content = c 
            console_insert(f"File Loaded Successfuly >> {content}")
            file.close()
    def SettingsWindow():
        Settingswindow = Tk() 
        Settingswindow.title("Settings")
        Settingswindow.geometry("420x420")
        Settingswindow.config(background="#454340")
        color_button = Button(Settingswindow, text="Change text color", command=change_color)
        color_button.grid(row=0, column=0)
        
        Settingswindow.mainloop()
    def CloseNova():
        window.destroy()
    def change_color(): 
        color = colorchooser.askcolor(title="Pick a color!")
        uinp.config(fg=color[1])
    def About():
        messagebox.showinfo(title="Info/TOS",message="Why was NovaCode created? NovaCode was made to educate starters to python, as well as other laugauges as a freetime project. What is NovaCode? NovaCode is a simplistic IDE for beginers which is open source. Join Our Discord: https://discord.gg/7YKCG6FT TOS: ")

    def Tab1():
        window.title("Tab1")
        global tab1_data, tab2_data
        tab1_data = uinp.get(1.0,END)
        uinp.delete(1.0,END)
        uinp.insert(END,tab2_data)
    def Tab2():
        window.title("Tab2")
        global tab2_data, tab1_data
        tab2_data = uinp.get(1.0,END)
        uinp.delete(1.0,END)
        uinp.insert(END,tab1_data)
    def Clock():
        master = Tk()
        master.title("NovaClock")

        def get_time(): 
            timeVar = time.strftime("%I:%M:%S %p")
            clock.config(text=timeVar)
            clock.after(200,get_time)

        clock = Label(master, font=("Calibri",90),bg="grey",fg="white")
        clock.pack()
        get_time()
        master.mainloop()
    m = Menu(window)
    fileMenu = Menu(m,tearoff=0)
    windowMenu = Menu(m,tearoff=0)
    m.add_cascade(label="File",menu=fileMenu)
    m.add_cascade(label="Window",menu=windowMenu)
    windowMenu.add_cascade(label="Tab1",command=Tab1)
    windowMenu.add_cascade(label="Tab2",command=Tab2)
    fileMenu.add_cascade(label="Save",command=SaveFile)
    fileMenu.add_cascade(label="New",command=newFile)
    fileMenu.add_cascade(label="Open",command=openFile)
    fileMenu.add_cascade(label="Quit",command=CloseNova)
    m.add_command(label="Execute",command=run_code)
    m.add_command(label="Settings",command=SettingsWindow)
    m.add_command(label="Clock",command=Clock)
    m.add_command(label="About",command=About)

    #Disable full screen
    #window.resizable(width=False,height=False)

    window.title("NovaCode")
    window.config(bg=bgc,menu=m)
    window.geometry(window_size_x+"x"+window_size_y)
    photo = PhotoImage(file = "logo.ico")
    myappid = 'novacode.novacode.novacode.version'
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
    window.iconphoto(False, photo)

    uinp = Text(width=window_size_x,bg=bgc,fg=fgc)
    uinp.pack(expand=True,fill="both")
    code_output = Text(bg="#454340",fg="lime",width=window_size_x) 
    code_output["state"] = DISABLED
    code_output.pack(expand=True,fill="both")

    window.mainloop()
if version != server_version: 
    with open("Data/rud.txt", "r") as f: 
        rud = f.read()
    if rud != server_version: 
        print("[-] NovaCode is running a older version")
        update = Tk()
        def skipUpdate(): 
            with open("Data/rud.txt", "w") as f: 
                f.write(server_version)
            update.destroy()
            main()
        def update_func():
            os.system("start http://novacode.lifeserverf.org/download.html#")
        update.config(background="#454340")
        update.title("Software Update")
        Button(text="Update",command=update_func).pack()
        Button(text="Skip Update (not reccomended)", command=skipUpdate).pack()
        
        update.mainloop()
    main()
else: 
    print("[+] NovaCode is up to date")
    main()